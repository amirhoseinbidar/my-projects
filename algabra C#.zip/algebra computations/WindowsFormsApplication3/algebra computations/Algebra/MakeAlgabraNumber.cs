﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algebra
{
   public class TopOfFractionLine
    {
        double real;
        char[] imaginary;
        public TopOfFractionLine()
        {
            real = 1;
            imaginary = new char[1];
        }
        public TopOfFractionLine(double real_, char[] imaginary_)
        {
            Real = real_;
            Imaginary = new char[imaginary_.Length];
            Imaginary = imaginary_;
        }
        public TopOfFractionLine(double real_, char imaginary_)
        {
            Real = real_;
            char[] imaginaryList = { imaginary_ };
            Imaginary = imaginaryList;
        }
        public TopOfFractionLine(TopOfFractionLine a)
        {
            Real = a.Real;
            Imaginary = a.Imaginary;
        }
        public double Real
        {
            get { return real; }
            set { real = value; }
        }
        public char[] Imaginary
        {
            get { return imaginary; }
            set
            {
                imaginary = new char[value.Length];
                imaginary = value;
            }
        }
        public int SetImaginaryLeng
        {
            set { imaginary = new char[value]; }
        }
        public TopOfFractionLine Set(double real_, char[] imaginary_)
        {
            TopOfFractionLine set = new TopOfFractionLine();
            set.Real = real_;
            set.Imaginary = imaginary_;
            return set;
        }
        public TopOfFractionLine Set(double real_, char imaginary_)
        {
            TopOfFractionLine set = new TopOfFractionLine();
            set.Real = real_;
            set.Imaginary[0] = imaginary_;

            return set;
        }
        public static TopOfFractionLine operator *(TopOfFractionLine a, TopOfFractionLine b)
        {
            TopOfFractionLine multiply = new TopOfFractionLine();
            multiply.Real = a.Real * b.Real;
            int k = 0;
            multiply.SetImaginaryLeng = a.Imaginary.Length + b.Imaginary.Length;
            foreach (char c in a.Imaginary)
            {
                multiply.Imaginary[k] = c;
                k++;
            }
            foreach (char c in b.Imaginary)
            {
                multiply.Imaginary[k] = c;
                k++;
            }
            return multiply;
        }
        public static TopOfFractionLine operator *(TopOfFractionLine a, DownOfFractionLine b)
        {
            TopOfFractionLine multiply = new TopOfFractionLine();
            multiply.Real = a.Real * b.Real;
            int k = 0;
            multiply.SetImaginaryLeng = a.Imaginary.Length + b.Imaginary.Length;
            foreach (char c in a.Imaginary)
            {
                multiply.Imaginary[k] = c;
                k++;
            }
            foreach (char c in b.Imaginary)
            {
                multiply.Imaginary[k] = c;
                k++;
            }
            return multiply;
        }
        public static TopOfFractionLine operator *(DownOfFractionLine a, TopOfFractionLine b)
        {
            TopOfFractionLine multiply = new TopOfFractionLine();
            multiply.Real = a.Real * b.Real;
            int k = 0;
            multiply.SetImaginaryLeng = a.Imaginary.Length + b.Imaginary.Length;
            foreach (char c in a.Imaginary)
            {
                multiply.Imaginary[k] = c;
                k++;
            }
            foreach (char c in b.Imaginary)
            {
                multiply.Imaginary[k] = c;
                k++;
            }
            return multiply;
        }

    }
   public class DownOfFractionLine
    {
        double real;
        char[] imaginary;
        public DownOfFractionLine()
        {
            real = 1;
            imaginary = new char[1];
        }
        public DownOfFractionLine(double real_, char[] imaginary_)
        {
            Real = real_;
            Imaginary = new char[imaginary_.Length];
            Imaginary = imaginary_;

        }
        public DownOfFractionLine(double real_, char imaginary_)
        {
            Real = real_;
            char[] imaginaryList = { imaginary_ };
            Imaginary = imaginaryList;
        }
        public DownOfFractionLine(DownOfFractionLine a)
        {
            Real = a.Real;
            Imaginary = a.Imaginary;
        }
        public double Real
        {
            get { return real; }
            set { real = value; }
        }
        public char[] Imaginary
        {
            get { return imaginary; }
            set
            {
                imaginary = new char[value.Length];
                imaginary = value;
            }
        }
        public int SetImaginaryLeng
        {
            set { imaginary = new char[value]; }
        }
        public DownOfFractionLine Set(double real_, char[] imaginary_)
        {
            DownOfFractionLine set = new DownOfFractionLine();
            set.Real = real_;
            set.Imaginary = imaginary_;
            return set;
        }
        public DownOfFractionLine Set(double real_, char imaginary_)
        {
            DownOfFractionLine set = new DownOfFractionLine();
            set.Real = real_;
            set.Imaginary[0] = imaginary_;

            return set;
        }
        public static DownOfFractionLine operator *(DownOfFractionLine a, DownOfFractionLine b)
        {
            DownOfFractionLine multiply = new DownOfFractionLine();
            multiply.Real = a.Real * b.Real;
            int k = 0;
            multiply.SetImaginaryLeng = a.Imaginary.Length + b.Imaginary.Length;
            foreach (char c in a.Imaginary)
            {
                multiply.Imaginary[k] = c;
                k++;
            }
            foreach (char c in b.Imaginary)
            {
                multiply.Imaginary[k] = c;
                k++;
            }
            return multiply;
        }

    }
   public class AlgebraNumber
    {
        private TopOfFractionLine Up;
        private DownOfFractionLine Down;
        public AlgebraNumber()
        {
            Up = new TopOfFractionLine();
            Down = new DownOfFractionLine();
        }
        public AlgebraNumber(TopOfFractionLine a, DownOfFractionLine b)
        {
            AlgebraNumber Number = new AlgebraNumber();
            Number = Simplify(a, b);
            Up = Number.Up;
            Down = Number.Down;
        }
        public void SetAlgebraNumber(TopOfFractionLine a, DownOfFractionLine b)
        {
            AlgebraNumber Number = new AlgebraNumber();
            Number = Simplify(a, b);
            Up = Number.Up;
            Down = Number.Down;
        }
        public override string ToString()
        {
            string UpImaginary = "";
            string DownImaginary = "";
            foreach (char a in Up.Imaginary)
            {
                UpImaginary += a;
            }
            foreach (char a in Down.Imaginary)
            {
                DownImaginary += a;
            }

            return (Up.Real + "" + UpImaginary + " / " + Down.Real + "" + DownImaginary);
        }
        private static bool Search(char[] a, char[] b)
        {
            int k = 0;
            bool c = false;
            foreach (char s in a)
            {
                if (b.Contains(s))
                    k++;
            }
            if (a.Length == k && b.Length == k)
                c = true;
            return c;
        }
        public static AlgebraNumber operator +(AlgebraNumber a, AlgebraNumber b)
        {
            if (a.Down.Real == b.Down.Real && Search(a.Down.Imaginary, b.Down.Imaginary))
            {

                if (Search(a.Up.Imaginary, b.Up.Imaginary))
                {
                    AlgebraNumber sum = new AlgebraNumber();
                    sum.Up.Real = a.Up.Real + b.Up.Real;
                    sum.Up.Imaginary = a.Up.Imaginary;
                    sum.Down.Real = a.Down.Real;
                    sum.Down.Imaginary = a.Down.Imaginary;
                    return sum;
                }
                else
                {
                    throw new System.ArithmeticException();
                }
            }
            else
            {
                AlgebraNumber sum = new AlgebraNumber();
                AlgebraNumber value1 = new AlgebraNumber();
                AlgebraNumber value2 = new AlgebraNumber();

                value1.Down = a.Down * b.Down;
                value2.Down = value1.Down;
                value1.Up = a.Up * b.Down;
                value2.Up = a.Down * b.Up;

                sum = value1 + value2;
                return sum;
            }
        }
        public static AlgebraNumber operator -(AlgebraNumber a, AlgebraNumber b)
        {
            if (a.Down.Real == b.Down.Real && Search(a.Down.Imaginary, b.Down.Imaginary))
            {

                if (Search(a.Up.Imaginary, b.Up.Imaginary))
                {
                    AlgebraNumber minus = new AlgebraNumber();
                    minus.Up.Real = a.Up.Real - b.Up.Real;
                    minus.Up.Imaginary = a.Up.Imaginary;
                    minus.Down.Real = a.Down.Real;
                    minus.Down.Imaginary = a.Down.Imaginary;
                    return minus;
                }
                else
                {
                    throw new System.ArithmeticException();
                }
            }
            else
            {
                AlgebraNumber minus = new AlgebraNumber();
                AlgebraNumber value1 = new AlgebraNumber();
                AlgebraNumber value2 = new AlgebraNumber();

                value1.Down = a.Down * b.Down;
                value2.Down = value1.Down;
                value1.Up = a.Up * b.Down;
                value2.Up = a.Down * b.Up;

                minus = value1 - value2;
                return minus;
            }
        }
        public static AlgebraNumber operator *(AlgebraNumber a, AlgebraNumber b)
        {
            AlgebraNumber Data = new AlgebraNumber();
            Data.Up = a.Up * b.Up;
            Data.Down = a.Down * b.Down;
            Data=AlgebraNumber.Simplify(Data.Up ,Data.Down);
            return Data;
        }
        public static AlgebraNumber operator /(AlgebraNumber a, AlgebraNumber b)
        {
            AlgebraNumber division = new AlgebraNumber();
            DownOfFractionLine x = new DownOfFractionLine(b.Down);
            b.Down.Real = b.Up.Real;
            b.Down.Imaginary = b.Up.Imaginary;

            b.Up.Real = x.Real;
            b.Up.Imaginary = x.Imaginary;

            division = a * b;

            division = Simplify(division.Up, division.Down);

            return division;
        }
        public static AlgebraNumber operator ^(AlgebraNumber a, AlgebraNumber b)
        {
            AlgebraNumber exponent = new AlgebraNumber();
            return exponent;
        }
        public static AlgebraNumber Simplify(TopOfFractionLine Up, DownOfFractionLine Down)
        {
            AlgebraNumber Data = new AlgebraNumber(); 

            for (int i = 0; i < (int)(Up.Real + Down.Real); i++)
            {
                double Value = SimplifyNumbers(Up.Real, Down.Real);

                if (Value != -1)
                {
                    Up.Real /= Value;
                    Down.Real /= Value;
                }
                else
                    break;
            }


            foreach (char k in Up.Imaginary)
            {
                bool l = Down.Imaginary.Contains(k);
                if (l)
                {
                    int z = Array.IndexOf(Up.Imaginary, k);
                    Array.Clear(Up.Imaginary, z, 1);
                    int c = Array.IndexOf(Down.Imaginary, k);
                    Array.Clear(Down.Imaginary, c, 1);
                }
            }

            Data.Down = Down;
            Data.Up = Up;

            Data = AlgebraNumber.Simplify(Data);

            return Data;

        }
        private static AlgebraNumber Simplify(AlgebraNumber Number)
        {
            char [] DataUp ;
            char [] DataDown ;
            int k = 0;
            int t = 0;
            foreach (char s in Number.Up.Imaginary )
            {
                if (s!='\0')
                {
                    k++;
                }
            }
            DataUp = new char[k];
            foreach (char s in Number.Up.Imaginary )
            {
                if (s != '\0')
                {
                    DataUp[t] = s;
                    t++;
                }
            }


             k = 0;
             t = 0;
            foreach (char s in Number.Down.Imaginary)
            {
                if (s != '\0')
                {
                    k++;
                }
            }
            DataDown = new char[k];
            foreach (char s in Number.Down.Imaginary)
            {
                if (s != '\0')
                {
                    DataDown[t] = s;
                    t++;
                }
            }

            Number.Down.Imaginary = DataDown;
            Number.Up.Imaginary = DataUp;

            return Number;

        }
        private static double SimplifyNumbers(double a, double b)
        {
            double[] aval = { 2, 3, 5, 7, 11, 13 };
            double Data = -1;
            foreach (double c in aval)
            {
                if (a % c == 0 && b % c == 0)
                {
                    Data = c;
                    break;
                }
            }
            return Data;
        }
    }
}
