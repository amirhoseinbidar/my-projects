﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Algebra_Control
{
   public struct Size_Location
   {
      public int Width;
      public int Height;
      public int Top;
      public int Left;

      public static Size_Location make_SizeLocation(int Width, int Height, int Top, int Left)
      {
          Size_Location m;
          m.Left = Left;
          m.Height = Height;
          m.Top = Top;
          m.Width = Width;
          return m;
      }
   }

   public struct changesTool
   {
       public Size_Location Form;
       public Size_Location basicControl;
       public Size_Location[] otherControls; 
       public static changesTool make_changesTool(Size_Location Form,Size_Location basicControl,Size_Location[] otherControls)
       {
           changesTool Data;
           Data.Form = Form;
           Data.basicControl=basicControl;
           Data.otherControls = otherControls;

           return Data;
       }
       public static changesTool make_changesTool(Size_Location Form,Size_Location basicControl,Size_Location otherControls)
       {
           changesTool Data;
           Data.Form = Form;
           Data.basicControl = basicControl;
           Size_Location[] s = { otherControls }; 
           Data.otherControls = s;

           return Data;
       }
   }
   
    class changes
    {
        private int locomotionValue;
        public int LocomotionValue
        {
            get {return locomotionValue ;}
            set { locomotionValue = value; }
        }
        public changesTool shorten (changesTool Tool, int basicControlprimalWidth, Keys e)
        {
            if (e == Keys.Back)
            {
                if (Tool.basicControl.Width > basicControlprimalWidth )
                {
                    Tool.basicControl.Width -= LocomotionValue;
                    Tool.Form.Left += locomotionValue/2;
                    Tool.Form.Width -= LocomotionValue;
                }
            }
            return Tool;
        }  
        public UserControl extrack_changes(UserControl form,Size_Location Tool)
        {
            form.Width = Tool.Width;
            form.Height = Tool.Height;
            form.Top = Tool.Top;
            form.Left = Tool.Left;

            return form;
        }
        public TextBox extrack_changes(TextBox textBox,Size_Location Tool)
        {
            textBox.Width = Tool.Width;
            textBox.Height = Tool.Height;
            textBox.Top = Tool.Top;
            textBox.Left = Tool.Left;

            return textBox;
        }

        public static bool Comparison(changesTool a)
        {
            bool data=false;
            foreach (Size_Location s in a.otherControls)
            {
                if (a.basicControl.Width > s.Width)
                    data = true;
            }
            return data;
        }
    }

    class DivisonControlChanges : changes
    {
        public changesTool BackSpace_changes(changesTool Tool, int basicControlprimalWidth, Keys e)
        {

            if (Tool.basicControl.Width > basicControlprimalWidth)
            {
                if (e == Keys.Back)
                {
                    Tool.basicControl.Width -= LocomotionValue;
                    if (Comparison(Tool))
                    {
                        Tool.Form.Width -= LocomotionValue;
                        if (Tool.otherControls != null)
                        {
                            int Number = 0;
                            foreach (Size_Location s in Tool.otherControls)
                            {
                                Size_Location m;
                                m = s;
                                m.Left = s.Left - LocomotionValue / 2;
                                Tool.otherControls[Number] = m;
                            }
                        }
                    }
                    else
                    {
                        Tool.basicControl.Left += LocomotionValue / 2;
                    }
                }
            }
            return Tool;
        }
        public changesTool otherKey_changes(changesTool Tool, bool IsBackSpace)
        {
            if (IsBackSpace == false)
            {
                Tool.basicControl.Width += LocomotionValue;
                if (Comparison(Tool))
                {
                    Tool.Form.Width += LocomotionValue;
                    if (Tool.otherControls != null)
                    {
                        int Number = 0;
                        foreach (Size_Location s in Tool.otherControls)
                        {
                            Size_Location m;
                            m = s;
                            m.Left = s.Left + LocomotionValue / 2;
                            Tool.otherControls[Number] = m;
                        }
                    }
                }
                else
                {
                    Tool.basicControl.Left -= LocomotionValue / 2;
                }
            }
            return Tool;
        }


    }

}
