﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algebra_Control
{
    // سازنده امیر حسین بیدار 
    // کنترل کسر برای برنامه محاسبه جبری

   
    public partial class DivisionControl : UserControl
    {
        public DivisionControl()
        {
            InitializeComponent(); 
                  
        }

        private void DivisionControl_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawLine(new Pen(Color.Black, 1), 0, this.Size.Height / 2, this.Size.Width, this.Size.Height / 2);           
        }

        private void down_SizeChanged(object sender, EventArgs e)
        {
            if (down.Width >= up.Width)
            {
                this.Width = down.Width + 20;
                up.Left = (this.Width / 2) - (up.Width / 2);
            }
            else
            {
                down.Left = (this.Width / 2) - (down.Width / 2);
            }
        }

        private void DivisionControl_FontChanged(object sender, EventArgs e)
        {
            up.Font = this.Font;
            down.Font = this.Font;
        }
        private void up_SizeChanged(object sender, EventArgs e)
        {
            if (up.Width >= down.Width)
            {
                this.Width = up.Width + 20;
                down.Left = (this.Width / 2) - (down.Width / 2);
            }
            else
            {
                up.Left = (this.Width / 2) - (up.Width / 2);
            }
           
        }

       
            
        

    }   
}
