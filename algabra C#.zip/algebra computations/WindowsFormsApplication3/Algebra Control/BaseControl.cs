﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algebra_Control
{
     

     public partial class BaseControl : TextBox
    {
         SizeF BaseSize = new SizeF();
         Keys key = new Keys();
         SizeF charectersLengh;

         public SizeF CharectersLengh
         {
             get { return charectersLengh; }
             set { charectersLengh = value; }
         }

       


         public BaseControl()
         {
             this.KeyDown += BaseControl_KeyDown;
             this.TextChanged += BaseControl_TextChanged;
         }

            
         public  Size Size
         {
             get {return base.Size;}

             set
             {
                 if (!DesignMode)
                     BaseSize = value;
    
                 base.Size = value;
             }
         }
         int NextLenght = 0;
         void BaseControl_TextChanged(object sender, EventArgs e)
         {
             if (!DesignMode)
             {
                 NextLenght = Text.Length;
                 if (!(NextLenght - 1 == UndoLenght || NextLenght == UndoLenght - 1))
                 {
                     BaseControl_KeyDown(sender, new KeyEventArgs(Keys.Back));
                     excepion = true;
                 }
                 Graphics s = this.CreateGraphics();
               
                 string m = this.Text + "b";
                 SizeF size = s.MeasureString(m, this.Font);
                 size.Width = (float)Math.Round(size.Width);

                 if (key != Keys.Back && (int)size.Width > BaseSize.Width)
                     this.Width = (int)size.Width;
                 if (key == Keys.Space && (int)size.Width > BaseSize.Width)
                     this.Width += (int)Font.Size;

                 s.Dispose();
                 key = new Keys();
             }
         }

         bool excepion = false;
         int UndoLenght = 0;
         void BaseControl_KeyDown(object sender, KeyEventArgs e)
         {
               if (Text != null)                    
                    CharectersLengh = this.CreateGraphics().MeasureString(this.Text, this.Font);
                    
                     
             if (!DesignMode)
             {
                 UndoLenght = Text.Length;

                 if (e.KeyCode == Keys.Back && this.Width > BaseSize.Width)
                 {
                     Graphics s = this.CreateGraphics();

                   
  
                     string m = this.Text + "b";
                     SizeF size = s.MeasureString(m, this.Font);
                     size.Width = (float)Math.Round(size.Width);

                     if (excepion == false)
                     this.Width = (int)size.Width;
                     else
                     {
                         if (this.Width < BaseSize.Width)
                             this.Width = (int)BaseSize.Width;
                         else
                             this.Width = (int)size.Width;
                     }
                     s.Dispose();
                 }

                 key = e.KeyCode;
             }
            
         }
    }
}
