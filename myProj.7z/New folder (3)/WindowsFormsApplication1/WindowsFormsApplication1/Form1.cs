﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Harekat harekat1 = new Harekat();
        public Form1()
        {
            InitializeComponent();
            harekat1.Left = label1.Left;
            harekat1.Top = label1.Top; 
        
           
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Top = harekat1.Top;
            label1.Left = harekat1.Left;
        }

       
    }
}
class Harekat
{
    int down, up,right,rast;
    int top,left;
    int zele_1,zele_2,zele_3;
    Timer mytimer = new Timer();
    public Harekat()
    {
        left = 100;
        top = 100;
        zele_1 = 10;
        zele_2 = 20;
        zele_3 = 10;
        up = -10;
        down = 10;
        right = -10;
        rast = 10;
        mytimer.Enabled = true;
        mytimer.Interval = 100;
        this.mytimer.Tick += new System.EventHandler(this.Mosalasy);
    }
    public int Top
    {
        get { return top; }
        set { top = value;}
    }
    public int Left
    {
        get { return left; }
        set { left = value; }
    }
    public int Down
    {
        get { return down; }
        set { down = value; }
    }
    public int Up
    {
        get { return up; }
        set { up = value; }
    }
    public int Right
    {
        get { return right ; }
        set { Right  = value; }
    }
    public int Rast
    {
        get { return rast; }
        set { rast  = value; }
    }
    public int Zele_1
    {
        get { return zele_1 ; }
        set { zele_1  = value; }
    }
    public int Zele_2
    {
        get { return zele_2; }
        set { zele_2 = value; }
    }
    public int Zele_3
    {
        get { return zele_3; }
        set { zele_3 = value; }
    }
    private void Mosalasy(object sender, EventArgs e)
    {
        if (zele_1 > 0)
        {
            left  += rast;
            top += down;
            zele_1--;
        }
        if (zele_1 == 0 && zele_2 > 0)
        {
            left += right;
            zele_2--;
        }
        if (zele_1 == 0 && zele_2 == 0 && zele_3 > 0)
        {
            left += rast;
            top += up;
            zele_3--;
        }
        if (zele_1 == 0 && zele_2 == 0 && zele_3 == 0)
        {
            zele_1 = 10; zele_2 = 20; zele_3 = 10;
        }
    }
}
