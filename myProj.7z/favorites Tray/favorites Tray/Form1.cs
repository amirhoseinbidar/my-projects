﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace favorites_Tray
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_VisibleChanged(object sender, EventArgs e)
        {
          
          
        }
  private void icnNotift_Click(object sender, EventArgs e)
        {
    
            // Create a new instance of the Favorites class
            Favorites_Viewer.favorites objFavorites =    new Favorites_Viewer.favorites();
            // Scan the Favorites folder
            objFavorites.scanFavoritesFolder();
            // Clear current menu items
            FavoritesMenu.Items.Clear();
            // Process each objWebFavorite object
            // in the Favorites collection
            foreach (Favorites_Viewer.selectUrlFile objWebFavorite in objFavorites.favoriteCollections)
            {
                // Declare a ToolStripMenuItem object
                ToolStripMenuItem objMenuItem =   new ToolStripMenuItem();
                // Set the properties of ToolStripMenuItem object
                objMenuItem.Text = objWebFavorite.Name;
                objMenuItem.Tag = objWebFavorite.Url;
                // Add a handler to Click event of new menu item
                objMenuItem.Click += new EventHandler(MenuItems_Click);
                // Add the ToolStripMenuItem object
                // to the ContextMenu
                FavoritesMenu.Items.Add(objMenuItem);
            }
            // Create a Seperator item and adding it
            // to context menu
            ToolStripSeparator objSeperatorItem = new ToolStripSeparator(); 
            FavoritesMenu.Items.Add(objSeperatorItem);
            // Create an Exit menu item and set it's properties
            ToolStripMenuItem objExitItem = new ToolStripMenuItem();
            objExitItem.Text = "Exit";
            objExitItem.Click += new EventHandler(ExitMenuItem_Click);

            // Add Exit menu item to context menu
            FavoritesMenu.Items.Add(objExitItem);
        }
      
      
        private void MenuItems_Click(object sender,System.EventArgs e)
        {
            // Create a ToolStripMenuItem
            // and fill it with sender parameter
            ToolStripMenuItem s = (ToolStripMenuItem)sender;
            // Open the internet explorer to view selected
            // favorite
            System.Diagnostics.Process.Start(s.Tag.ToString());
        }
        private void ExitMenuItem_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

     

        
      
    }
}
