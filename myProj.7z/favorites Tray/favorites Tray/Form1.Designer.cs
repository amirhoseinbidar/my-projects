﻿namespace favorites_Tray
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.icnNotift = new System.Windows.Forms.NotifyIcon(this.components);
            this.FavoritesMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SuspendLayout();
            // 
            // icnNotift
            // 
            this.icnNotift.ContextMenuStrip = this.FavoritesMenu;
            this.icnNotift.Icon = ((System.Drawing.Icon)(resources.GetObject("icnNotift.Icon")));
            this.icnNotift.Text = "Right-click me to view Favorites";
            this.icnNotift.Visible = true;
            this.icnNotift.Click += new System.EventHandler(this.icnNotift_Click);
            // 
            // FavoritesMenu
            // 
            this.FavoritesMenu.Name = "FavoritesMenu";
            this.FavoritesMenu.Size = new System.Drawing.Size(61, 4);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.ContextMenuStrip = this.FavoritesMenu;
            this.Name = "Form1";
            this.ShowInTaskbar = false;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.VisibleChanged += new System.EventHandler(this.Form1_VisibleChanged);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NotifyIcon icnNotift;
        private System.Windows.Forms.ContextMenuStrip FavoritesMenu;
    }
}

