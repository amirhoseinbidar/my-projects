﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace data_server
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            string Connected = @"Data Source = (LocalDB)\v11.0 ; AttachDBFileName = E:\programming\نیاز به توسعه\data server\person database.mdf";
            string culomns_Value = " [Names] NVARCHAR(200) NOT NULL , [preamble] NVARCHAR(MAX) NULL, [Customers_specification_Table_Name] NVARCHAR(200) NOT NULL";
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Data_poniter_Form(Connected,"Companys_Table","Customer_Table",culomns_Value,true));
        }
    }
}
