﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace data_server
{
    public partial class Data_poniter_Form : Form
    {
        #region Values
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand(); 
        bool OpenGroupBox = false;
        string tableName;
        string suffix;
        string Newculomns_Values;
        bool creatDataPoniterForm;
        #endregion 
        #region properties
        public bool CreatDataPoniterForm
        {
            get { return creatDataPoniterForm; }
            set { creatDataPoniterForm = value; }
        }
        public SqlConnection Connection
        {
            get { return con; }
            set { con = value; }
        }
        public string TableName
        {
            get { return tableName; }
            set { tableName = value; }
        }
        public string Suffix
        {
            get { return suffix; }
            set { suffix = value; }
        }
        public string NewCulomns_Values
        {
            get { return Newculomns_Values; }
            set { Newculomns_Values = value; }
        }
        #endregion 

        public Data_poniter_Form()
        {
            InitializeComponent();
            dataGridView1.Font = new System.Drawing.Font("Bookman Old Style", 12);
        }
        #region showDataBaseValues
        public Data_poniter_Form(string Connection, string TableName, string suffix ,string NewCulomns_Values, bool CreatDataPoniterForm)
        {
            InitializeComponent();
            dataGridView1.Font = new System.Drawing.Font("Bookman Old Style", 12);
          

            con.ConnectionString = Connection;
            cmd = con.CreateCommand();
            this.tableName = TableName;
            this.suffix = suffix;
            this.Newculomns_Values = NewCulomns_Values;
            this.creatDataPoniterForm = CreatDataPoniterForm;


            if (creatDataPoniterForm == false)
            {
                dataGridView1.Columns.Add("Costomers_Column", "Costomers");
                dataGridView1.Columns[0].Width = dataGridView1.Width;
            }
            else
            {
                dataGridView1.Columns.Add("Companys_Column", "Companys");
                dataGridView1.Columns[0].Width = dataGridView1.Width;
            }
            refreshList();    
        }
        private void refreshList()
        {
            this.dataGridView1.Rows.Clear();
            cmd.CommandText = string.Format("select Names From [{0}]",tableName);
            con.Open();

           
           
            SqlDataReader dr = cmd.ExecuteReader();
            int row = 0;
            while(dr.Read())
            {
                row = dataGridView1.Rows.Add();

               
               dataGridView1.Rows[row].ReadOnly = true;
               dataGridView1.Rows[row].Frozen = true;

               dataGridView1.Rows[row].Cells[0].Value = dr.GetValue(0);
            }
                
            con.Close();           
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
          
            if (string.IsNullOrEmpty(textBox1.Text) == false && string.IsNullOrWhiteSpace(textBox1.Text) == false)
            {
                try
                {
                    con.Open();
                 
                    cmd.CommandText = string.Format(@"insert into [{2}] values ('{0}','{1}','{0}_{3}')", textBox1.Text, preamble_box.Text, tableName ,this.suffix);

                    cmd.ExecuteNonQuery();


                    cmd.CommandText = string.Format("Create Table [{0}_{1}] ({2})", textBox1.Text, suffix, Newculomns_Values);
                    cmd.ExecuteNonQuery();

                    con.Close();

                    refreshList();
                    textBox1.Text = "";
                    preamble_box.Text = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    con.Close();
                }
            }
            else
                MessageBox.Show("Please write something for table name ");
        }
       
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {          
            foreach (DataGridViewRow s in dataGridView1.SelectedRows)
            {
                string Name = s.Cells[0].Value.ToString();

                con.Open();

                cmd.CommandText = string.Format(@"DELETE FROM [{0}] WHERE Names='{1}' ", this.tableName, Name);
                cmd.ExecuteNonQuery();

                cmd.CommandText = string.Format("DROP TABLE [{0}_{1}]", Name, this.suffix);
                cmd.ExecuteNonQuery();

                con.Close();
            } 
            refreshList();
        }  
  
        public virtual void OpenApp ()
        {
            string Name = string.Format("{0}_{1}", dataGridView1.SelectedCells[0].Value, suffix);
            if (creatDataPoniterForm)
            {
           string Culomns = "  [ID] INT  , [Date] DateTime  , [Name] NVARCHAR(100)  , [Task] NVARCHAR(200)  , [Number] INT  ,[worth] INT  ,[Sum] INT  ,[comment] NVARCHAR(MAX) ";
           Data_poniter_Form form;
                form = new Data_poniter_Form(this.con.ConnectionString, Name, string.Format("{0}_Customer_specification", dataGridView1.SelectedCells[0].Value), Culomns ,  false);

            form.Text = dataGridView1.SelectedCells[0].Value.ToString() + " customers"; 
           
            form.ShowDialog();
            }
            else
            {  
            
            Data_pointer_DataGridView Form = new Data_pointer_DataGridView(Connection.ConnectionString, Name);

            Form.ShowDialog();
            }
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        { 
            OpenApp();   
        }
        #endregion showDataBaseValues

       
        private void button1_Click(object sender, EventArgs e)
        {
                
                if (OpenGroupBox == false)
                {
                    OpenGroupBox = true;
                    groupBox1.Visible = true;

                }
                else
                {
                    if (this.Height < 590)
                    this.Height = 590;
                    OpenGroupBox = false;
                }

            dataGridView1.Anchor = AnchorStyles.Left | AnchorStyles.Right |AnchorStyles.Top;
                button1.Anchor = AnchorStyles.Left  | AnchorStyles.Top;
                groupBox1.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            timer1.Start();       
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (OpenGroupBox == false)
            {
                groupBox1.Height -= 10;
                this.Height -= 10;
                if (groupBox1.Height <= 0)
                {
                    groupBox1.Visible = false;
                    dataGridView1.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
                    button1.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
                    groupBox1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
                    timer1.Stop();
                }
            }
            else
            {
                groupBox1.Height += 10;
                this.Height += 10;
                if (groupBox1.Height >= 250)
                {
                    dataGridView1.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
                    button1.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
                    groupBox1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
                    timer1.Stop();
                }
            }
        }

        private void Data_poniter_Form_Resize(object sender, EventArgs e)
        {
            
        }
     
    }
}

