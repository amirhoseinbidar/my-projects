﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data.SqlTypes;

namespace data_server
{
    public partial class Data_pointer_DataGridView : Form
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        bool isDisineTime = true;
        string TableName;
        public Data_pointer_DataGridView(string Connection,string TableName)
        {
         

            InitializeComponent();
            isDisineTime = true;
            con.ConnectionString = Connection;
            this.TableName = TableName;


            con.Open();
            cmd = new SqlCommand(string.Format("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{0}'",TableName),con);

            SqlDataReader dr =  cmd.ExecuteReader();
            while(dr.Read())
            {
                DataGridViewTextBoxColumn s = new DataGridViewTextBoxColumn();
                s.HeaderText = dr.GetString(0);

                dataGridView2.Columns.Add(s);
            }
            dr.Close();


            cmd.CommandText = string.Format("SELECT * FROM [{0}]",TableName);
            dr = cmd.ExecuteReader();

           
            while(dr.Read())
            {
                int row = dataGridView2.Rows.Add();

                for (int i = 0; i < dataGridView2.ColumnCount; i++)
                {
                    dataGridView2.Rows[row].Cells[i].Value = dr.GetValue(i);
                }
            }            
            dr.Close();
            con.Close();

            isDisineTime = false;
        }

        bool focusedOnCell = false;
        int Cell_rowIndex = 0;
        int Cell_ColumnIndex = 0;
        string Cell_ErrorMessage;
        private void dataGridView2_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {           
            if (focusedOnCell && Cell_rowIndex == e.RowIndex && Cell_ColumnIndex == e.ColumnIndex)
            {
                focusedOnCell = false;
                dataGridView2.Rows[Cell_rowIndex].Cells[Cell_ColumnIndex].ErrorText = "";
            }
            if (isDisineTime == false && isRowAdded == false)
            {
                string ColumnName = "";
                object CellValue = null;

                foreach (DataGridViewCell s in dataGridView2.SelectedCells)
                {
                    ColumnName = dataGridView2.Columns[s.ColumnIndex].HeaderText;
                    Cell_rowIndex = s.RowIndex;
                    Cell_ColumnIndex = s.ColumnIndex;
                    CellValue = s.Value;
                }

                con.Open();
                if (CellValue == null)
                    CellValue = "";

               string Text = string.Format("UPDATE [{0}] SET [{1}] = N'{2}' WHERE ",TableName, ColumnName, CellValue );

                for (int i = 0 ;  i < dataGridView2.ColumnCount ; i++)
                {
                    if (dataGridView2.Columns[i].HeaderText != ColumnName)
                        Text += string.Format(" [{0}] = N'{1}'  AND"  , dataGridView2.Columns[i].HeaderText , dataGridView2.Rows[Cell_rowIndex].Cells[i].Value );
                }

              Text = Text.Remove(Text.Length - 4);

                cmd.CommandText = Text;

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    focusedOnCell = true;
                    Cell_ErrorMessage = ex.Message;
                    MessageBox.Show(Cell_ErrorMessage);                 
                    dataGridView2.Rows[Cell_rowIndex].Cells[Cell_ColumnIndex].ErrorText = ex.Message; 
                }
                con.Close();
            }
        }
         private void dataGridView2_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (focusedOnCell == true && (Cell_rowIndex != e.RowIndex || Cell_ColumnIndex != e.ColumnIndex))
            {
                dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Selected = false;
                dataGridView2.Rows[Cell_rowIndex].Cells[Cell_ColumnIndex].Selected = true;         
            }
        }




        private void dataGridView2_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            con.Open();
            foreach (DataGridViewRow s in dataGridView2.SelectedRows)
            {
                string Text = string.Format("DELETE FROM [{0}] WHERE ", TableName);

                for (int i = 0; i < dataGridView2.ColumnCount; i++)
                        Text += string.Format(" [{0}] = N'{1}'  AND", dataGridView2.Columns[i].HeaderText, dataGridView2.Rows[s.Index].Cells[i].Value);
                

                Text = Text.Remove(Text.Length - 4);

                cmd.CommandText = Text;

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            con.Close();

            if (focusedOnRow == true && dataGridView2.Rows[e.Row.Index] == dataGridView2.Rows[addedRowIndex])
            {
                isRowAdded = false;
                focusedOnRow = false;
            }
         
        }
        




       private void dataGridView2_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (isDisineTime == false)
            {
                addedRowIndex = e.RowIndex - 1;
                isRowAdded = true;
            }
        }
        int addedRowIndex;
        bool isRowAdded = false;
        bool focusedOnRow = false;
        string rowError;
        private void dataGridView2_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (focusedOnRow == true && dataGridView2.Rows[e.RowIndex] != dataGridView2.Rows[addedRowIndex])
            {
                dataGridView2.Rows[e.RowIndex].Selected = false;
                dataGridView2.Rows[addedRowIndex].Selected = true;
            }
            if(isDisineTime == false && isRowAdded == true )
            {
                con.Open();
                string Text = string.Format("INSERT INTO [{0}] VALUES (",TableName);
                for (int i = 0; i < dataGridView2.ColumnCount; i++ )
                {
                    Text += string.Format(" N'{0}' ,", dataGridView2.Rows[addedRowIndex].Cells[i].Value);
                }
                Text = Text.Remove(Text.Length - 1);
                Text += ")";

                cmd.CommandText = Text;
               
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }                      
                    catch (SqlException ex)
                    {
                        rowError = ex.Message;
                        MessageBox.Show(ex.Message);
                        dataGridView2.Rows[addedRowIndex].ErrorText = ex.Message;
                        dataGridView2.Rows[e.RowIndex].Selected = false;
                        dataGridView2.Rows[addedRowIndex].Selected = true;
                        focusedOnRow = true;
                    }

                con.Close();
                isRowAdded = false;
            } 
       
            if (focusedOnRow == true && dataGridView2.Rows[e.RowIndex] == dataGridView2.Rows[addedRowIndex])
            {
                isRowAdded = true;
                focusedOnRow = false;
                dataGridView2.Rows[addedRowIndex].ErrorText = "";
            }
        }

        private void dataGridView2_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (focusedOnRow == true && dataGridView2.Rows[addedRowIndex] != dataGridView2.Rows[e.RowIndex])
            {
                dataGridView2.Rows[addedRowIndex].Selected = true;
             
                e.Cancel = true; 
                dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Selected = false; 
            }
            if (focusedOnCell && dataGridView2.Rows[Cell_rowIndex].Cells[Cell_ColumnIndex] != dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex])
            {
                dataGridView2.Rows[Cell_rowIndex].Cells[Cell_ColumnIndex].Selected = true;

                e.Cancel = true;
                dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Selected = false; 
            }
        }

      

       

      

        

       

       

      

      
    }
}
