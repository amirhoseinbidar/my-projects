﻿using System;
using System.Collections.Generic;
using System.Text;


namespace TimerProj
{
    public struct Time 
    {
        public short hour;
        public short minute;
        public short second;

        public static Time operator +(Time a, Time b)
        {
            Time data = new Time();
            if (data.second > 60)
            {
                data.minute += 1;
                data.second -= 60;
            }
            data.second = (short)(a.second + b.second);


            data.minute += (short)(a.minute + b.minute);
            if (data.minute > 60)
            {
                data.hour += 1;
                data.minute -= 60;
            }

            data.hour += (short)(a.hour + b.hour);
            if (data.hour > 24)
            {
                data.hour += 1;
                data.hour -= 24;
            }
            return data;
        }
        public static Time operator +(Time a, DateTime b)
        {
            Time data = new Time();
            if (data.second > 60)
            {
                data.minute += 1;
                data.second -= 60;
            }
            data.second = (short)(a.second + b.Second);


            data.minute += (short)(a.minute + b.Minute);
            if (data.minute > 60)
            {
                data.hour += 1;
                data.minute -= 60;
            }

            data.hour += (short)(a.hour + b.Hour);
            if (data.hour > 24)
            {
                data.hour += 1;
                data.hour -= 24;
            }
            return data;
        }
        public static Time operator -(Time a, Time b)
        {

            a.second -= b.second;
            if (a.second < 0)
            {
                a.minute -= 1;
                a.second += 60;
            }
            a.minute -= b.minute;

            if (a.minute < 0)
            {
                a.hour -= 1;
                a.minute += 60;
            }

            a.hour -= b.hour;
        
            return a;


        }
        public static bool operator !=(Time a, Time b)
        {
            if (a.hour != b.hour && a.minute != b.minute && a.second != b.second)
                return true;
            return false;
        }
        public static bool operator ==(Time a, Time b)
        {
            if (a.hour == b.hour && a.minute == b.minute && a.second == b.second)
                return true;
            return false;
        }
        public static bool operator >(Time a, Time b)
        {
            if (a.hour == b.hour)
                goto lable1;
            if (a.hour > b.hour)
                return true;
            else
                return false;

            lable1:

            if (a.minute == b.minute)
                goto lable2;
            if (a.minute > b.minute)
                return true;
            else
                return false;

            lable2:

            if (a.second > b.second)
                return true;
            else
                return false;
        }
        public static bool operator <(Time a, Time b)
        {
            if (a.hour == b.hour)
                goto lable1;
            if (a.hour < b.hour)
                return true;
            else
                return false;

        lable1:

            if (a.minute == b.minute)
                goto lable2;
            if (a.minute < b.minute)
                return true;
            else
                return false;

        lable2:

            if (a.second < b.second)
                return true;
            else
                return false;
        }
        public override string ToString()
        {
            return string.Format("{0,00}:{1,00}:{2,00}", hour, minute, second);
        }

    }
    public class setTimes
    {
        public Time[] selectedTimes;
        public Time[] Times;
        public Time nowTime;
        public bool[] Types;

        // مقادیری که ما از فرم تنظیم زمان ها به دست می آوریم خام هستند و باید بر اساس نوع آنها 
        // تغییراتی در آنها ایجاد شوند این دو متد این کار را میکنند
        public Time[] selectTimes()
        {
            if (Times == null)
                return null;
            Time[] Data = new Time[this.Times.Length];
            int m = 0;
            foreach (Time s in this.Times)
            {
                if (Types[m] == true)
                    Data[m] = s + this.nowTime;
                else
                    Data[m] = s;
                
                m++;
            }
            selectedTimes = Data;
            return Data;
        }
        public Time[] selectTime(int index, Time SystemDate)
        {
            Time[] Data = this.selectTimes();

            if (Types[index] == true)
            {
                Data[index] = Times[index] + SystemDate;
                selectedTimes[index] = Times[index] + SystemDate;
            }
            return Data;
        }

        // این متدها بررسی میکند که دو اراییه دقیقا مطابق یکدیگر هستند یا خیر
        public bool IsEqual(Time[] Data, Time[] obj)
        {

            if (Data == null || obj == null)
                return false;
            if (Data.Length != obj.Length)
                return false;

            int m = 0;
            foreach (Time s in Data)
            {
                if (s != obj[m])
                    return false;
            }
            return true;
        }
        public bool IsEqual(bool[] Data, bool[] obj)
        {
            if (Data == null || obj == null)
                return false;
            if (Data.Length != obj.Length)
                return false;

            int m = 0;
            foreach (bool s in Data)
            {
                if (s != obj[m])
                    return false;
            }
            return true;
        }

        public Time[] Add(Time[] obj, Time data)
        {
            Time[] store = obj;
            if (obj != null)
                obj = new Time[store.Length + 1];
            else
                obj = new Time[1];
            int s = 0;
            if (store != null)
            {
                foreach (Time i in store)
                {
                    obj[s] = i;
                    s++;
                }
            }
            obj[s] = data;

            return obj;
        }
        public bool[] Add(bool[] obj, bool data)
        {
            bool[] store = obj;
            if (obj != null)
                obj = new bool[store.Length + 1];
            else
                obj = new bool[1];
            int s = 0;
            if (store != null)
            {
                foreach (bool i in store)
                {
                    obj[s] = i;
                    s++;
                }
            }
            obj[s] = data;

            return obj;
        }

        public Time[] Remove(Time[] obj, int index)
        {
            Time[] data;
            if (obj != null)
                data = new Time[obj.Length - 1];
            else
                return obj;

            byte k = 0;
            bool l = false;
            foreach (Time s in obj)
            {
                if (k != index && l == false)
                    data[k] = s;

                if (l == true)
                {
                    k--;
                    data[k] = s;
                    k++;
                }
                if (k == index)
                    l = true;
                k++;
            }
            return data;
        }
        public bool[] Remove(bool[] obj, int index)
        {
            bool[] data;
            if (obj != null)
                data = new bool[obj.Length - 1];
            else
                return obj;

            byte k = 0;
            bool l = false;
            foreach (bool s in obj)
            {
                if (k != index && l == false)
                    data[k] = s;

                if (l == true)
                {
                    k--;
                    data[k] = s;
                    k++;
                }
                if (k == index)
                    l = true;

                k++;
            }
            return data;
        }

        public bool search(Time obj, Time[] list)
        {
            bool m = false;
            int k = 0;
            if (list != null)
                foreach (Time s in list)
                {
                    if (s == obj)
                    {
                        m = true;
                    }
                    k++;
                }
            return m;
        }
    }
}

   
