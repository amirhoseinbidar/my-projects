﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace TimerProj
{
    public partial class TimeControl : UserControl
    {
        public delegate void _ClickOnDelete(string text, bool IsthisValueEveryTime);
        public event _ClickOnDelete ClickOnDelete;
        private void DeleteBtn_Click(object sender, EventArgs e)
        {   
            this.ClickOnDelete(this.Time.Text,IsthisValueEveryTime);        
            this.Dispose();
        }
        public TimeControl()
        {
            InitializeComponent();
        }
         public void Time_TypeText (bool Write_EveryTime)
        {
            if (Write_EveryTime == true)
                Time_Type.Text = "Every";
            else
                Time_Type.Text = "On";
        }
        public void TimeText(string timeText)
         {
             Time.Text = timeText;
         }
         public string TimeTextValue
         {
             get { return Time.Text; }
         }
        public bool IsthisValueEveryTime
         {
             get
             {
                 if (this.Time_Type.Text == "Every")
                     return true;
                 else
                     return false;
             }
         }
      
    }
}
