﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TimerProj;
using System.Collections;

namespace WindowsFormsApplication8
{

    public partial class TimerForm : Form
    {

        public delegate void IsClicOnBeQuait(bool clickOn);
        public event IsClicOnBeQuait ClickOnBeQuait;
        private void but_BeQuiet_Click(object sender, EventArgs e)
        {
            this.ClickOnBeQuait(true);
            this.but_BeQuiet.Visible = false;
        }

        DateTime SystemTime;
        setTimes set = new setTimes();    

        public TimerForm()
        {
            InitializeComponent();
           
        }

        public void setTime(Time NowTime, bool Type, Time Times)
        {
            set.Times = new Time[1];
            set.Types = new bool[1];

            set.Times[0] = Times;
            set.nowTime = NowTime;
            set.Types[0] = Type;

            set.selectTimes();
            RefreshItems();
        }
        public void setTime (Time NowTime,bool [] Type , Time [] Times)
        {
            set.Times = Times;
            set.Types = Type;
            set.nowTime = NowTime;

            set.selectTimes();
            RefreshItems();
        }

        private void RefreshItems()
        {
          int m = 1;
         foreach (Time s in set.selectedTimes)
         {
             TimePoniter TimePoniter = new TimePoniter();

             TimePoniter.Text = s.ToString();

             int l = 37 * m;
             TimePoniter.Left = 12;
             TimePoniter.Top = l;
             TimePoniter.Name = "Poniter";

             if (l > but_BeQuiet.Top - 10)
             {
                 this.Height += 37;
                 but_BeQuiet.Top += 37;
             }

             TimePoniter.Refresh(this.Controls, this);

             this.Controls.Add(TimePoniter);
             

             m++;
         }


        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            SystemTime = DateTime.Now; 
            Time Date;

            Date.hour = (short)SystemTime.Hour;
            Date.minute = (short)SystemTime.Minute;
            Date.second = (short)SystemTime.Second;

           
            int l = 0;           
                foreach (Control h in this.Controls)
                {
                    if (h.Name == "Poniter")
                    {
                        if (set.Types[l])
                        {
                            if (set.selectedTimes[l] > Date)
                                h.Text = (set.selectedTimes[l] - Date).ToString();
                            else
                                h.Text = (Date - set.selectedTimes[l]).ToString();
                        }
                        else
                        {
                            Time o = new Time();
                            o.second = 59;
                            o.minute = 59;
                            o.hour = 23;
                            if (set.selectedTimes[l] > Date)
                                h.Text = ((o - Date) - (o - set.selectedTimes[l])).ToString();
                            else
                                h.Text = (o - (Date - set.selectedTimes[l])).ToString();
                        }
                        l++;
                    }
                }
          

            // در اینجا میبینیم که زمان سیستم برابر با یکی از زمان های تنظیم شده است یا خیر           
            int k = 0;
            if (set.Times != null)
                foreach (Time s in set.selectedTimes)
                {
                    if (s == Date)
                    {               
                        set.selectedTimes = this.set.selectTime(k, Date);
                        but_BeQuiet.Visible = true;
                    }
                    k++;
                }            
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
           label4.Text = string.Format ("{0,00}:{1,00}:{2,00}",SystemTime.Hour,SystemTime.Minute,SystemTime.Second);
        }

        private void Form1_Load(object sender, EventArgs e)
        {        
            timer1.Enabled = true;
            timer2.Enabled = true;
        }

        private void timePoniter1_Load(object sender, EventArgs e)
        {

        }

        private void gنئ_Enter(object sender, EventArgs e)
        {

        }
    }
}
