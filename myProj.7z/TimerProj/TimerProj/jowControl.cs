﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace TimerProj
{
    public partial class jowControl : Form
    {
        // این یک مقدار برای تعداد تمام کنترل ها است 
        // چون تمام مقادیر برگشتی باید به یک تعداد باشند از یک مفدار استفاده کردیم
        int Count=0;   
        // تمام زمان های ذخیره شده
       public  Time [] time ;
        // تمام نوع زنگ هایی که ذخیره شده
       public  bool [] OnTheEveryTime;
        //لسیت کنترل ها
       ArrayList TimeControls = new ArrayList();

        public jowControl()
        {
            InitializeComponent();
        }

      
        // در این رویداد ما اطلاعات را از کاربر گرفته  ذخیره کرده بر روی فرم 
        //یک سری کنترل را به نمایش گذاشته و موارد ذخیره شده را بر میگردانیم
        private void button1_Click(object sender, EventArgs e)
        {
            // در این قسمت مقادیر ذخیره شده بررسی می شود تا اطمینان حاصل شود
            // از این که کاربر مقادیر تکراری وارد نمیکند 
            bool Bool = false;
            string saveTime = string.Format("{0,00}:{1,00}:{2,00}", hour.Value, minute.Value, second.Value);
            foreach (TimeControl i in TimeControls)
            {
                if (i.TimeTextValue == saveTime && i.IsthisValueEveryTime == this.onTheEveryTimeChBtn.Checked)
                    Bool = true;
            }

            if (Bool == false)
            {
                // زمان خواسته شده در یک آرایه  شامل تمام زمان های ذخیره شده ذخیره میشود
                Time m;
                m.hour = (byte)hour.Value;
                m.minute = (byte)minute.Value;
                m.second = (byte)second.Value;

                addItems(m, onTheEveryTimeChBtn.Checked);
            }
        }

        public void addItems(Time Time_obj,bool OnTheEveryTime_obj)
        {
            // زمان خواسته شده در یک آرایه  شامل تمام زمان های ذخیره شده ذخیره میشود

            time = Add(time, Time_obj);

            // نوع زنگ زدن نیز همچنین
            OnTheEveryTime = Add(OnTheEveryTime, OnTheEveryTime_obj);
            

            // کنترل مخصوص زمان  می سازیم مقادیر ان را بسته به درخواست تنظیم و ان را به فرم اضافه میکنیم
            TimeControl Control = new TimeControl();
            Control.Time_TypeText(OnTheEveryTime[Count]);
            Control.TimeText(string.Format("{0,00}:{1,00}:{2,00}", Time_obj.hour, Time_obj.minute, Time_obj.second));

            Control.Top = this.Height - Control.Height * 2;
            Control.Left += 50;
            this.Height += Control.Height;

            TimeControls.Add(Control);
            this.Controls.Add(Control);

            // در اینجا یک رویداد می سا زیم تا هنگامیکه کاربر یکی از کنترل ها را حذف کرد یک سری اتفاقات بیافتد
            Control.ClickOnDelete += Control_ClickOnDelete;

            // سپس به مقدار تعداد ارایه ها یک اضافه میکنیم
            Count++;
        }
        public void addItems(Time [] Time_obj , bool [] OnTheEveryTime_obj)
        {
            if (Time_obj == null || OnTheEveryTime_obj == null)
                return;

            for (int i = 0; i < Time_obj.Length; i++)
            {
                addItems(Time_obj[i], OnTheEveryTime_obj[i]);
            }
        }


        // در این رویداد ما کنترل انتخاب شده  برای حذف را پیدا کرده 
        // اطلاعات مربوط به آن را حذف کرده وبقیه کنترل ها را مرتب کنیم  
        // همچنین این رویداد یک سری اطلا عات در باره ی کنترل  حذف شده به ما میدهد
        void Control_ClickOnDelete(string text, bool IsthisValueEveryTime)
        {
            // ابتدا از طول ارایه ها یک عدد کم میکنیم
            Count--;
            // سپس فرم را به اندازهی یک کنترل زمان کوتاه میکنیم
            this.Height -= 22;

            int s = 0;
            //   این شرط برای مرتب کردن کنترل های بعدی کنترل حذف شده استفاده میشود  
            bool IsThis = false;     
             foreach (TimeControl i in TimeControls)
                {
                 // بررسی میکند که ایا کنترل انتخاب شده کنترل حذف شده است یا نه 
                 // اگر آره مقادیر مربوط به آن کنترل را حذف کرده و میگوید کنترل های بعدی باید جابه جا شوند
                    if (text == i.TimeTextValue && IsthisValueEveryTime == i.IsthisValueEveryTime)
                    {
                       this.time = Remove(this.time, s);
                       this.OnTheEveryTime = Remove(this.OnTheEveryTime, s);
                       IsThis = true;
                    }
                 // اگر کنترل  بعد از کنترل حذف شده باشد جا به جا میشود
                    if (IsThis == true)
                    i.Top -= 22;
                 s++;
                }
             s = 0;
            // سپس کنترل حذف شده را از لیست کنترل ها حذف میکنیم
             foreach (TimeControl i in TimeControls)
             {
                 if (text == i.TimeTextValue && IsthisValueEveryTime == i.IsthisValueEveryTime)
                 {
                     TimeControls.RemoveRange(s, 1);
                     break;
                 }
                 s++;
             }
        }

        Time[] Add(Time[] obj, Time data)
        {
            Time[] store = obj;
            if (obj != null)
                obj = new Time[store.Length + 1];
            else
                obj = new Time[1];
            int s = 0;
            if (store != null)
            {
                foreach (Time i in store)
                {
                    obj[s] = i;
                    s++;
                }
            }
            obj[s] = data;

            return obj;
        }
        bool[] Add(bool[] obj, bool data)
        {
            bool[] store = obj;
            if (obj != null)
                obj = new bool[store.Length + 1];
            else
                obj = new bool[1];
            int s = 0;
            if (store != null)
            {
                foreach (bool i in store)
                {
                    obj[s] = i;
                    s++;
                }
            }
            obj[s] = data;

            return obj;
        }

        Time[] Remove(Time [] obj , int index)
        {
            Time[] data;
            if (obj != null)
                data = new Time[obj.Length - 1];
            else
                return obj;

            byte k = 0;
            bool l = false;
            foreach (Time s in obj)
            {
                if (k != index && l == false)
                    data[k] = s;

                if (l == true)
                {
                    k--;
                    data[k] = s;
                    k++;
                }
                if (k == index)
                    l = true;
                k++;
            }
            return data;
        }
        bool[] Remove(bool[] obj, int index)
        {
            bool[] data;
            if (obj != null)
                data = new bool[obj.Length - 1];
            else
                return obj;

            byte k = 0;
            bool l = false;
            foreach (bool s in obj)
            {
                if (k != index && l == false)
                    data[k] = s;

                if (l == true)
                {
                    k--;
                    data[k] = s;
                    k++;
                }
                if (k == index)
                    l = true;
                
                k++;             
            }
            return data;
        }



    }
}
