﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TimerProj
{
    public partial class minimumForm : Form
    {
        // محل فایل صوتی
        string strAudioPath = @"C:\Users\amirhosean\Desktop\TimerProj\TimerProj\MUSIC.WAV";
        // یک پخش کننده ی فایل صوتی
        System.Media.SoundPlayer audio = new System.Media.SoundPlayer();
        // متغییری که زمان سییتم را نگهداری میکند
        DateTime SystemDate;

        setTimes set = new setTimes();
        
       
       
        

        public minimumForm()
        {
            InitializeComponent();
            //این رویداد هنگامی که کاربر برنامه را میبندد اجرا میشود
            Disposed += minimumForm_Disposed;

            //  تایمر را غیر فعال میکنیم تا بعد از مقدار دهی فعال شود
            timer1.Enabled = false;
            //  در شروع کار ابتدا از کاربر میخواهیم مقادیری وارد کند
            clocksJowTimeToolStripMenuItem.PerformClick();
            // سپس تایمر را فعال میکنیم
            timer1.Enabled = true;
            // سپس نمایش دهندهی تایمر را فعال میکنیم
            openToolStripMenuItem.PerformClick();           
        }

        void minimumForm_Disposed(object sender, EventArgs e)
        {
            // هنگام خارج شدن برنامه ابتدا به چند متد که فرم های دیگر را کنترل میکنند میگوییم 
            // که فرم هایی که در دست دارند از دور خارج کنند
            Closejow = true;
            CloseForm = true;
            Closejow = true;

            // سپس انها را اجرا میکنیم تا دستورات اجرا شود
            openToolStripMenuItem.PerformClick();
            clocksJowTimeToolStripMenuItem.PerformClick();
            changeAudioToolStripMenuItem.PerformClick();
        }      

        private void timer1_Tick(object sender, EventArgs e)
        {
            // اینجا ساعت سیستم را به دست می آوریم
            SystemDate = DateTime.Now;
            
            //سپس ان را در  یک متغییر قرار میدهیم
            Time Date;
            Date.hour = (short)SystemDate.Hour;
            Date.minute = (short)SystemDate.Minute;
            Date.second = (short)SystemDate.Second;

            // در اینجا میبینیم که زمان سیستم برابر با یکی از زمان های تنظیم شده است یا خیر
            bool m =false;
            int k = 0;
            if (set.Times != null)
            foreach (Time s in set.selectedTimes)
            {
                if (s == Date)
                {
                    m = true;
                    set.selectedTimes =this.set.selectTime(k,Date);
                }
                k++;
            }
            // اگر بود 
            if (m)
            {
               Audio(true);               
               beQuaitToolStripMenuItem.Visible = true;              
            }
        }
        // این برای این است که هنگام اجرای صدا دوباره نشود
        bool IsStart=false;
        private void Audio(bool start)
        {
            if (start == true && IsStart == false)
            {
                audio.SoundLocation = strAudioPath;
                audio.Load();
                audio.Play();
                IsStart = true;
            }
            if (start == false && IsStart == true)
            {
                audio.Stop();
                IsStart = false;
            }
        }
        // برنامه را به صورت کامل از دید به جز ایکون بغل مخفی میکند
        private void minimumForm_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true)
                this.Visible = false;
        }
       
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
        }

        // این متد اطلا عات موجود را به فرم نمایش میفرستد تا به نمایش در آیند
        bool IsOpen_form=false;
        bool CloseForm;     
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WindowsFormsApplication8.TimerForm form = new WindowsFormsApplication8.TimerForm();
            if (CloseForm == true)
                form.Dispose();
            // مقادیر موجود را در صورت تهی نبودن به فرم میفرستد 
            if (set.Times != null)
                form.setTime(set.nowTime, set.Types, set.Times);
            // اگر فرم بسته باشد
            if (IsOpen_form == false)
            {

                IsOpen_form = true;
              
                // سپس یک رویداد سکوت برنامه از فرم میگیریم که هنگامی که در انجا بر 
                // روی دکمه سکوت کلیک شد ما از این اقدام مطلع شویم
                form.ClickOnBeQuait += form_ClicOnBeQuait;
                form.ShowDialog(); 
                // تا زمانی که فرم بسته نشود کامپایلر به خط زیر نمیرود
                // این یکی رو تو  این برنامه فهمیدم واقعا جالبهههههه
                IsOpen_form = false;
            }
           
            

        }

        void form_ClicOnBeQuait(bool clicOn)
        {
            if (clicOn == true)
            beQuaitToolStripMenuItem.PerformClick();
        }
       
        private void beQuaitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Audio(false);
            beQuaitToolStripMenuItem.Visible = false; 
        }

        // این متد برای بدست اوردن دستورات از کاربر است که یک  کنترل زمان زنگ زدن 
        // ایجاد میکند و اطلاعات مورد نیاز را از او میگیرد
        bool IsOpen_jow = false;
        bool Closejow;
        private void clocksJowTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            jowControl jow = new jowControl();

           if ( Closejow == true)
                jow.Dispose();  

          
            if (IsOpen_jow == false)
            {
                // مقادیر به دست امده از دستورات قبلی کاربر را به برنامه میفرستیم 
                //  تا به صورت کنترل های بصری درآیند
                jow.addItems(set.Times, set.Types);
                IsOpen_jow = true;
                jow.ShowDialog();
                IsOpen_jow = false;
                int m=0;
                // اینجا بررسی میکنیم ایا انچه دستور داده شده با انچه از قبل ذخیره شده
                // برابر است اگر نبود مقادیر را ذخیره میکند
                if (!(set.IsEqual(set.Times, jow.time) && set.IsEqual(set.Types, jow.OnTheEveryTime)))
                {
                    try
                    {
                        this.set.Times = new Time[jow.time.Length];
                        this.set.Types = new bool[jow.time.Length];

                        foreach (Time s in jow.time)
                        {
                            if (jow.time != null)
                                this.set.Times[m] = s;
                            m++;
                        }
                        m = 0;
                        foreach (bool s in jow.OnTheEveryTime)
                        {
                            if (jow.OnTheEveryTime != null)
                                this.set.Types[m] = s;
                            m++;
                        }
                    }
                    catch (System.NullReferenceException)
                    {
                        set.Times = null;
                        set.Types = null;
                    }
                    set.nowTime.hour = (short)DateTime.Now.Hour;
                    set.nowTime.minute = (short)DateTime.Now.Minute;
                    set.nowTime.second = (short)DateTime.Now.Second;
                }

                set.selectedTimes = this.set.selectTimes();
            }
           
        }

        bool IsOpen_ChangeAudio = false;
        bool closeChangeAudio;
        // اینم برای تغییر زنگ آهنگ
        private void changeAudioToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (closeChangeAudio == true)
                dialog.Dispose();

            if (IsOpen_ChangeAudio == false)
            {
                IsOpen_ChangeAudio = true;
                dialog.Filter = "|*.wav";

                Audio(false);
                timer1.Enabled = false;

                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    strAudioPath = dialog.FileName;
                IsOpen_ChangeAudio = false;
                timer1.Enabled = true;
            }
        }  


      



       
          
      

       
    }
}
