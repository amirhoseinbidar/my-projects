﻿namespace TimerProj
{
    partial class minimumForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(minimumForm));
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.beQuaitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeAudioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clocksJowTimeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "Timer";
            this.notifyIcon1.Visible = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem,
            this.openToolStripMenuItem,
            this.toolStripMenuItem1,
            this.beQuaitToolStripMenuItem,
            this.changeAudioToolStripMenuItem,
            this.clocksJowTimeToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(160, 142);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(156, 6);
            // 
            // beQuaitToolStripMenuItem
            // 
            this.beQuaitToolStripMenuItem.Name = "beQuaitToolStripMenuItem";
            this.beQuaitToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.beQuaitToolStripMenuItem.Text = "be quait";
            this.beQuaitToolStripMenuItem.Visible = false;
            this.beQuaitToolStripMenuItem.Click += new System.EventHandler(this.beQuaitToolStripMenuItem_Click);
            // 
            // changeAudioToolStripMenuItem
            // 
            this.changeAudioToolStripMenuItem.Name = "changeAudioToolStripMenuItem";
            this.changeAudioToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.changeAudioToolStripMenuItem.Text = "Change Audio";
            this.changeAudioToolStripMenuItem.Click += new System.EventHandler(this.changeAudioToolStripMenuItem_Click_1);
            // 
            // clocksJowTimeToolStripMenuItem
            // 
            this.clocksJowTimeToolStripMenuItem.Name = "clocksJowTimeToolStripMenuItem";
            this.clocksJowTimeToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.clocksJowTimeToolStripMenuItem.Text = "Clock jow Time ";
            this.clocksJowTimeToolStripMenuItem.Click += new System.EventHandler(this.clocksJowTimeToolStripMenuItem_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // minimumForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "minimumForm";
            this.Text = "minimumForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.VisibleChanged += new System.EventHandler(this.minimumForm_VisibleChanged);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem beQuaitToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem changeAudioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clocksJowTimeToolStripMenuItem;


    }
}