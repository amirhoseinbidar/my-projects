﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace TimerProj
{
    public partial class TimePoniter : UserControl
    { 
           TextBox Box = new TextBox();
        public TimePoniter()
        {
            InitializeComponent();

            this.Click += comment_Click;

            Box.Name = "Box";
            Box.Font = new Font("Arial Narrow", 9.75f, FontStyle.Regular);
            Box.Width = 130;
            Box.Height = this.Height;
            Box.Multiline = false;
            Box.KeyDown += Box_KeyDown;
            Box.Visible = false;

            this.Controls.Add(Box);
        }

        void Box_KeyDown(object sender, KeyEventArgs e)
        {
            if (Box.Text.Length > 15 && !(e.KeyCode == Keys.Back || e.KeyCode == Keys.Delete
               || e.KeyCode == Keys.Left || e.KeyCode == Keys.Right ))
                e.SuppressKeyPress = true;
            else
                e.SuppressKeyPress = false;   
        }
     
       
         
        
        public override string Text
        {
            get
            {
                return Time.Text;
            }
            set
            {
                Time.Text = value;
            }
        }

        bool IsBoxAdd = false;
        bool clickOnComment = false;
        private void comment_Click(object sender, EventArgs e)
        {
            comment.Visible = false;

            Box.Width = 130;
            Box.Height = this.Height;
            Box.Visible = true;
            
            IsBoxAdd = true;
            clickOnComment = true;
        }
        public void Refresh(ControlCollection FormControls , Control Form)
        {
            foreach (Control s in this.Controls)
            {
                if (s.Name != "Box")
                s.Click += s_Click;
            }      
            foreach (Control s in FormControls)
            {
                s.Click += s_Click;
            }
            Form.Click += s_Click;
        }       
        void s_Click(object sender, EventArgs e)
        {            
         
            if (IsBoxAdd == true && clickOnComment == false)
            {             
                foreach (Control s in this.Controls)
                {
                    if (s.Name == "Box")
                    {
                        comment.Text = s.Text;
                        s.Visible = false ;
                        comment.Visible = true;
                        IsBoxAdd = false;
                    }
                }
            }
            if (clickOnComment)
                clickOnComment = false;
        }

        
    }
}
