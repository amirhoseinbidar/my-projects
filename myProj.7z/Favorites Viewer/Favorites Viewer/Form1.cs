﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Favorites_Viewer
{
    public partial class Form1 : Form
    {
        // مکان قرار گرفتن فایل های ذخیره که اطلاعاتی که ما در برنامه ذخیره میکنیم را نگه داری میکنند
        string strSavePath_Name = @"C:\Users\hamed\Desktop\نیاز به توسعه\Favorites Viewer\Favorites Viewer\stringSavePath\FilesName.txt";
        string strSavePath_URL = @"C:\Users\hamed\Desktop\نیاز به توسعه\Favorites Viewer\Favorites Viewer\stringSavePath\FilesURL.txt";
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
            // این بخش اطلاعات فایلهای ذخیره را در لیست بارگذاری میکند
            favorites a = new favorites();
            a.LoadOnSaveFile(strSavePath_URL, strSavePath_Name);
            for (int i = a.Name.Length, b = 0; i > b; b++)
            {
                ListViewItem objListViewItem = new ListViewItem();
                objListViewItem.Text = a.Name[b];
                objListViewItem.SubItems.Add(a.URL[b]);
                lstFavorites.Items.Add(objListViewItem);
            }

        }
        // این متد به شما امکان میدهد فولدری را که میخواهید بارگذاری کنید پیدا کنید
        private void folderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ObjFolderBrowserDialog = new FolderBrowserDialog();
            ObjFolderBrowserDialog.ShowNewFolderButton = false;
            if (ObjFolderBrowserDialog.ShowDialog()==DialogResult.OK)
            {
                favorites objFavorites = new favorites();
                objFavorites.scanFavoritesFolder(ObjFolderBrowserDialog.SelectedPath);
                addToList(objFavorites);
            }
        }
        // این متد به شما امکان میدهد فایلی را که میخواهید بارگذاری کنید پیدا کنید
        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog objOpenFileDialog = new OpenFileDialog();
            objOpenFileDialog.Filter = "File|*.url";
            if (objOpenFileDialog.ShowDialog() == DialogResult.OK)
            {
                favorites objFavorites = new favorites();
                objFavorites.scanFavoritesFile(objOpenFileDialog.FileName);
                addToList(objFavorites);

            }
        }
        //این متد برای راحتی است ودر واقع بخش اصلی بارگذاری را انجام میدهد
        private void addToList (favorites a)
        {
           
            foreach (selectUrlFile objWebFavorite in a.favoriteCollections)
            {
                ListViewItem objListViewItem = new ListViewItem();
                objListViewItem.Text = objWebFavorite.Name;
                objListViewItem.SubItems.Add(objWebFavorite.Url);
                lstFavorites.Items.Add(objListViewItem);
            }
        }
        // این متد اصلاعات ایتمی که بر روی آن کلیک شده را به لینک آبی میفرستد
        private void lstFavorites_Click(object sender, EventArgs e)
        {
            lnkUrl.Text = "Visit " + lstFavorites.SelectedItems[0].Text;
            lnkUrl.Links.Clear();
            lnkUrl.Links.Add(6, lstFavorites.SelectedItems[0].Text.Length,lstFavorites .SelectedItems [0].SubItems[1].Text);
          
        }
        // این متد اطلاعات را ذخیره میکند
        private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Save save = new Save();
            save.saveFile(strSavePath_Name, strSavePath_URL, lstFavorites);
            
        }
        // این متد مورورگر پیشفرض را باز کرده و سایت انتخابی را باز میکند
        private void lnkUrl_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(e.Link.LinkData.ToString());
        }
       
    }

}
