﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;

namespace Favorites_Viewer
{
    // وظیفه این کلاس پیدا کردن فایل ها و اصلاح انها است
    class favorites
    {
        // اصلاح شده که شامل نام سایت و نشانی آنها می شود url یک کلکسیون برای ذخیره فایلهای   
        public ArrayList favoriteCollections = new ArrayList();
       // این آرایه های رشته ای مقدار فایل ذخیره را در خود نگه میدارند
        string[] name;
        string[] Url;

       //  این متد ها مقدار متغییرها را بر میگرداند
        public  string []  Name
        {
            get {return  name; }
        }
       public string [] URL
        {
            get { return Url; }
        }

        // را بر می گرداند favorites  این متد مکان قرار گیری فولدر 
        public string FavoritesFolder
        {
            get
            {
                return Environment.GetFolderPath(Environment.SpecialFolder.Favorites);
            }
        }
        //را به عنوان مقدار پیش فرض  به متد بعدی میفرستد favoritesاین متد ،متد پیش فرض است که  فولدر 
        public void scanFavoritesFolder()
        {
            scanFavoritesFolder(this.FavoritesFolder);
        }
  // فرستاده و سپس شی را در کولکسیون قرار میدهد selectUrlFile  انرا جدا کرده وبرای اصلاح به شی ای از کلاس  url این متد فولدری انتخاب شده جستوجو کررده و فایل های 
                     
        public void scanFavoritesFolder(string FolderPath)
        {
            foreach (string strFile in System.IO.Directory .GetFiles(FolderPath))
            {
                if(strFile.EndsWith(".url",true,null))
                {
                    selectUrlFile objWebFavorite = new selectUrlFile();
                    objWebFavorite.selectURLFile(strFile);
                    favoriteCollections.Add(objWebFavorite);
                }
            }
        }
        // این متد فقط یک فایل انتخابی را به کولکسیون اضافه میکند
        public void scanFavoritesFile(string FilePath)
        {
            string strFile = FilePath;
            if (strFile.EndsWith(".url", true, null))
            {
                selectUrlFile objWebFavorite = new selectUrlFile();
                objWebFavorite.selectURLFile(strFile);
                favoriteCollections.Add(objWebFavorite);
            }
        }
        // این متد مکان فایل های ذخیره را میگیرد وبا استفاده از آن محتویات ان ها را در یک متغییر نگه میدارد
        public void LoadOnSaveFile(string URLFilePath, string NameFilePath)
        {
            name = new string[File.ReadAllText(NameFilePath).Split('\n').Length];
            Url = new string[File.ReadAllText(URLFilePath).Split('\n').Length];
            name = File.ReadAllText(NameFilePath).Split('\n');
            Url = File.ReadAllText(URLFilePath).Split('\n');
        }
    } 

}
