﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Favorites_Viewer
{
    class Save
    {
        public void saveFile(string NamesFilePath, string URLsFilePath, ListView listView)
        {
            ListView List = new ListView();
            List = listView;
            string Names = NamesFilePath;
            string URLs = URLsFilePath;

            File.WriteAllText(Names, "");
            for (int i = List.Items.Count, a = 0; i > a; a++)
            {
                foreach (char charName in List.Items[a].Text)
                {
                    File.AppendAllText(Names, charName + "");
                }
                File.AppendAllText(Names, "\r\n");
            }

            File.WriteAllText(URLs, "");
            for (int i = List.Items.Count, a = 0; i > a; a++)
            {
                foreach (char charURL in List.Items[a].SubItems[1].Text)
                {
                    File.AppendAllText(URLs, charURL + "");
                }
                File.AppendAllText(URLs, "\r\n");
            }

        }
    }
}
