﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Favorites_Viewer
{
    class selectUrlFile
    {
        public string Name ;
        public string Url ;
        // را اصلاح میکند url  این متد فایل های 
       public void selectURLFile(string FilePath)
        {
            string strData;
            string[] strLines;
           //این شی اطلاعات یک فایل را برمیگرداند
            FileInfo objFileInfo = new FileInfo(FilePath);
           // چدا کردن پسوند از نام
            Name = objFileInfo.Name.Substring(0, objFileInfo.Name.Length - objFileInfo.Extension.Length);
           // قرار دادن نمام اطلاعات فایل ورودی در متغییر
            strData = File.ReadAllText(FilePath);
           // جدا کردن خط به خط اطلاعات
            strLines = strData.Split('\n');
           // جدا کردن ادرس سایت از اطلاعات
            foreach (string strLine in strLines)
            {
                if (strLine.StartsWith("URL="))
                {
                    Url = strLine.Substring(4);
                    break;
                }
            }
       }
    }
}