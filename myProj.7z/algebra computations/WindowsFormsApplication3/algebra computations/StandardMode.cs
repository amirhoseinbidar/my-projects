﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Algebra;

namespace WindowsFormsApplication3
{
   
    public partial class StandardMode : Form
    {
        public StandardMode()
        {
            InitializeComponent();
            
        }
        public AlgebraNumber m = new AlgebraNumber();
        

        private void StandardMode_Load(object sender, EventArgs e)
        {
            AlgebraNumber c = new AlgebraNumber();
            char [] m ={'s','f','t'};
            char [] k= {'s','f','e'};
            TopOfFractionLine balaii = new TopOfFractionLine(3, 't');
            DownOfFractionLine Paiiny = new DownOfFractionLine(4,m);
            TopOfFractionLine balaii1 = new TopOfFractionLine(7, k);
            DownOfFractionLine Paiiny1 = new DownOfFractionLine(6, 't');
            AlgebraNumber a = new AlgebraNumber(balaii, Paiiny);
            AlgebraNumber b = new AlgebraNumber(balaii1, Paiiny1);
            
            try
            {
                c = a - b;
                foreach (char s in c.ToString())
                {
                    textBox1.Text += s;
                }
            }
            catch
            {
                textBox1.Text = a + " + " + b;
            }
          
        }

       

    
        private void textBox2_CausesValidationChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_ChangeUICues(object sender, UICuesEventArgs e)
        {

        }

        private void textBox2_CursorChanged(object sender, EventArgs e)
        {
            e.GetHashCode();
        }

        private void textBox2_ImeModeChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            
        }

      

        private void textBox2_ParentChanged(object sender, EventArgs e)
        {

        }

      

        private void textBox2_HideSelectionChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Layout(object sender, LayoutEventArgs e)
        {

        }      
    }
}
