﻿namespace Algebra_Control
{
    partial class DivisionControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DivisionControl));
            this.down = new Algebra_Control.BaseControl();
            this.up = new Algebra_Control.BaseControl();
            this.SuspendLayout();
            // 
            // down
            // 
            resources.ApplyResources(this.down, "down");
            this.down.Name = "down";
            this.down.SizeChanged += new System.EventHandler(this.down_SizeChanged);
            // 
            // up
            // 
            resources.ApplyResources(this.up, "up");
            this.up.Name = "up";
            this.up.SizeChanged += new System.EventHandler(this.up_SizeChanged);
            // 
            // DivisionControl
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.Controls.Add(this.down);
            this.Controls.Add(this.up);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "DivisionControl";
            this.FontChanged += new System.EventHandler(this.DivisionControl_FontChanged);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.DivisionControl_Paint);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BaseControl up;
        private BaseControl down;










    }
}
