﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Algebra_Control
{
    public partial class exponentControl : UserControl
    {
        BaseControl baseControl1 = new BaseControl(); 
        public exponentControl()
        {
            InitializeComponent();
            this.Font = new System.Drawing.Font("", 15,FontStyle.Italic);
            baseControl1.Font = this.Font;
            baseControl1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            baseControl1.Width = 30;
            this.Width = baseControl1.Width;
            this.Height = baseControl1.Height;

            baseControl1.TextChanged += baseControl1_TextChanged;
            baseControl1.SizeChanged += baseControls_SizeChanged;
            baseControl1.KeyDown += baseControl1_KeyDown;

            this.Controls.Add(baseControl1);
        }

        void baseControl1_TextChanged(object sender, EventArgs e)
        {
            if (ifTextboxNullDispose == true && baseControl1.Text == "")
            {
                this.Dispose();
            }
        }
        
        private void baseControls_SizeChanged(object sender, EventArgs e)
        {
            int m = 0;
             foreach (Control s in this.Controls)
             {
                 if (m < s.Left + s.Width)
                     m = s.Left + s.Width;
             }

                this.Width = m ;   
        }

       
        
        private void baseControl1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Shift && Keys.D6 == (Keys)e.KeyValue)
                e.SuppressKeyPress = true;
            else
                e.SuppressKeyPress = false;


            int left;
            if (e.Shift && Keys.D6 == (Keys)e.KeyValue &&
                !(baseControl1.Text.EndsWith(" ")) && baseControl1.Text != "")
            {
                left = (int)(this.baseControl1.Left + baseControl1.CharectersLengh.Width);
                BaseControl BC = new BaseControl();

                Font f = new Font(this.Font.FontFamily , (this.Font.Size -5) , FontStyle.Italic ,Font.Unit ,Font.GdiCharSet , Font.GdiVerticalFont);                
                BC.Font = f;              
                BC.Left = left;
                BC.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                BC.Width = 30;
                this.Height += BC.Height;
                BC.SizeChanged += baseControls_SizeChanged;
                this.Controls.Add(BC);
            } 
                  
        }

        
        bool ifTextboxNullDispose;
        public bool IfTextboxNullDispose
        {
            get { return ifTextboxNullDispose; }
            set { ifTextboxNullDispose  = value;}
        }



        
    }
}
