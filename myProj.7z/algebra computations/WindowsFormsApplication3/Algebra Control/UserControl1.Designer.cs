﻿namespace Algebra_Control
{
    partial class UserControl1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControl1));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.wswsxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edwscToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ewdwcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wdxwedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Button = new System.Windows.Forms.PictureBox();
            this.textbox = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Button)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.AccessibleRole = System.Windows.Forms.AccessibleRole.ComboBox;
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wswsxToolStripMenuItem,
            this.edwscToolStripMenuItem,
            this.ewdwcToolStripMenuItem,
            this.wdxwedToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(118, 92);
            // 
            // wswsxToolStripMenuItem
            // 
            this.wswsxToolStripMenuItem.Name = "wswsxToolStripMenuItem";
            this.wswsxToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.wswsxToolStripMenuItem.Text = "wswsx";
            // 
            // edwscToolStripMenuItem
            // 
            this.edwscToolStripMenuItem.Name = "edwscToolStripMenuItem";
            this.edwscToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.edwscToolStripMenuItem.Text = "edwsc";
            // 
            // ewdwcToolStripMenuItem
            // 
            this.ewdwcToolStripMenuItem.Name = "ewdwcToolStripMenuItem";
            this.ewdwcToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.ewdwcToolStripMenuItem.Text = "ewdwc";
            // 
            // wdxwedToolStripMenuItem
            // 
            this.wdxwedToolStripMenuItem.Name = "wdxwedToolStripMenuItem";
            this.wdxwedToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.wdxwedToolStripMenuItem.Text = "wdxwed";
            // 
            // Button
            // 
            this.Button.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Button.ContextMenuStrip = this.contextMenuStrip1;
            this.Button.Image = ((System.Drawing.Image)(resources.GetObject("Button.Image")));
            this.Button.Location = new System.Drawing.Point(94, -1);
            this.Button.Name = "Button";
            this.Button.Size = new System.Drawing.Size(31, 87);
            this.Button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button.TabIndex = 4;
            this.Button.TabStop = false;
            // 
            // textbox
            // 
            this.textbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textbox.Font = new System.Drawing.Font("MRT_Omid", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.textbox.Location = new System.Drawing.Point(3, 31);
            this.textbox.Name = "textbox";
            this.textbox.Size = new System.Drawing.Size(89, 23);
            this.textbox.TabIndex = 5;
            // 
            // UserControl1
            // 
            this.AllowDrop = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.textbox);
            this.Controls.Add(this.Button);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(125, 85);
            this.Click += new System.EventHandler(this.UserControl1_Click);
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Button)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem wswsxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edwscToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ewdwcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wdxwedToolStripMenuItem;
        private System.Windows.Forms.PictureBox Button;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox textbox;
    }
}
