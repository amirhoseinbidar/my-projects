﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace selectReadingFile
{
    public partial class Form1 : Form
    {
        ChangeWords myselectWords = new ChangeWords();
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            char[] a = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '~', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '!', '@', '#', '$', '%', '^', '&', '*', '_', '+', '"', '/', '\\' };
            char[] b = new char[] { '~', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '!', '@', '#', '$', '%', '^', '&', '*', '_', '+', '"', '/', '\\', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            myselectWords.selectWords(a, b);
            textBox2.Text  =   myselectWords.change(textBox1.Text);
        ;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog savefile_1 = new SaveFileDialog();
            savefile_1.Filter = "TextFile|*.txt";
            if (savefile_1.ShowDialog()==DialogResult .OK)
            System.IO.File.WriteAllText(savefile_1.FileName,textBox2.Text);
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            OpenFileDialog openFile_1 = new OpenFileDialog();
            openFile_1.Filter = "TextFile|*.txt";
            if (openFile_1.ShowDialog() == DialogResult.OK && System.IO.File.Exists(openFile_1.FileName))
                textBox1.Text = System.IO.File.ReadAllText(openFile_1.FileName);
        }

    }
   
}
