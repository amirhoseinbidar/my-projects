﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace selectReadingFile
{

    class ChangeWords
    {
       // (کلماتی که میخواهیم تبدیلشان کنیم     (ورودی   
        char[] Entree;
       //    (کلماتی که میخواهیم به دست بیاوریم      (خروجی    
        char[] Emersion;
       public void selectWords(char [] entree,char [] emerson)
        {
            Emersion = emerson;
            Entree = entree;
        }
        
        public string change(string text)
        {
            // یک آرایه از نوع رشته ای به طول متن که تمام کلمات تبدیل شده را در خود نگه میدارد
            string[] RecordArray = new string[text.Length];
            //  یک رشته شامل  تمام کلمات تغییر داده شده به هم چسبیده
            string RecordString="";
            //  حلقه به تعداد کلمات داده شده میچرخد و هر واژه متن را از به ترتیب جدا میکند مورد برسسی قرار میدهد
            for (int i = 0; i < text.Length; i++)
            {
                // واژه ی جدا شده را در خود نگهداری میکند Wordمتغییر 
              char Word = text[i];  
                //این حلقه به تعداد واژه هایی که میخواهیم تبدیلشان کنیم میچرخد
                for (int a = 0; a < Entree.Length; a++)
                {
                    //  این دستور در صورتی که کلمه جدا شده از متن با یک از کلمه هایی که میخواهیم تبدیلش کنیم متابقت داشت اجرا میشود 
                    if (Word == Entree[a])
                    {
                       // در صورتی که عمللیات با موفقیت روبه رو شد واژه جایکزین به جای واژه ی جدا شده در آرایه ذخیره میشود
                        RecordArray[i] += Emersion[a];
                        break;
                    }
                    // این دستور در صورتی که تمام کلمات خواسته شده امتحان شده باشد اجرا میشود 
                    if (a == Entree.Length-1)
                    {
                        //در صورتی که شرط با موفقیت اجرا شد این دستور واژه جدا شده از متن را در آرایه ذخیره میکند 
                        RecordArray[i] += Word;
                        break;
                    }
                }
                 
            }
            //  حلقه ، آرایه واژه های تغییر یافته را به هم میچسباند و به یک رشته  تبدیل میکند
            foreach (string a in RecordArray) 
            {
                RecordString += a;
            }
            return RecordString;
           
        }
    }
}
