﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Threading;
namespace database_myVideos_Locations
{
    public partial class Form1 : Form
    {
        Find F = new Find();
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        static string Data = " ";
       
        public Form1()
        {
            InitializeComponent();
            F.Added += F_Added;
            F.Disposing += F_Disposing;

            timer.Tick += t_Tick;
            timer.Interval = 5000;
           
        }

       static int WorkersNumbers =0;
       static int idleWorkersNumber =0;
       
        private void button2_Click(object sender, EventArgs e)
        {
          
            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (DialogResult.OK == FBD.ShowDialog())
            {
              
                
                Thread t = new Thread(delegate() { F.AllFolders(FBD.SelectedPath); });
                label1.Text = "Please wait...";
                pictureBox1.Visible = true;
                richTextBox1.Text = ""; 
                t.Start();
                timer.Start();
                WorkersNumbers = 1;
            }  
        }
        private void button1_Click(object sender, EventArgs e)
        {

            string[] LD = Directory.GetLogicalDrives();
              WorkersNumbers = LD.Length;
              foreach (string s in LD)
              {

                  Thread t = new Thread(delegate() { F.AllFolders(s); });
                  t.IsBackground = true;
                  t.Name = s;
                  t.Start();

                  label1.Text = "Please wait...";
                  pictureBox1.Visible = true;
                  richTextBox1.Text = "";
                  timer.Start();
              }
        }

        void F_Disposing(object sender, EventArgs e)
        {
             idleWorkersNumber++;
        }

        static bool b;
        bool c;
        void t_Tick(object sender, EventArgs e)
        {
            this.richTextBox1.Text += Data;
            Data = "";

            if(b== true ||c==true )
            {
                b = false;
                timer.Stop();
            }
            if (idleWorkersNumber == WorkersNumbers)
            {
                WorkersNumbers = 0;
                idleWorkersNumber = 0;
                label1.Text = "Search is complete";
                pictureBox1.Visible = false;
                c = true;
            }
           


           
        }
        // این  متد فایل های ویدیویی را پیدا کرده و موقعیت انها را نشان میدهند
        void F_Added(object sender, EventArgs e)
        {
            try
            {
                string [] strpaths = Directory.GetFiles(sender.ToString());
                foreach (string s in strpaths)
                {
                    string x = Path.GetExtension(s);
                    if (x == ".mkv" || x == ".mp4" || x == ".avi" || x == ".3gp" || x == ".bik" || x == ".flv" || x == ".mpg" || x == ".wmv" || x == ".mov" || x == ".mpeg" || x == ".vob" || x == ".yuv" || x == ".amv" || x == ".avi" || x == ".mpg" || x == ".mpe" || x == ".m4e" || x == ".nsv" || x == ".f4b")
                    {
                        Form1.Data += s.ToString() + "\r\n";

                    }
                }
            }
            catch { }
            if (idleWorkersNumber == WorkersNumbers)
                b = true;
         
        }
    }
}
