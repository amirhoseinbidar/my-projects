﻿using System.Collections.Generic;
using System.IO;
using System;

namespace database_myVideos_Locations
{
    class Find
    {
        //  سازنده : امیرحسین بیدار کهنمویی
        // 6/12/1395 شمسی
        
        //فولدری که یافت میکند را برمیگرداند 
        public delegate void FindOneFolder(object sender, EventArgs e);
        public event FindOneFolder Added;
        public delegate void beforeDispose(object sender, EventArgs e);
        public event beforeDispose Disposing;
        static object locker = new object();
        public void AllFolders(string location)
        {
            string[] LD = {""};
            lock (locker)
            {              
                try { LD = Directory.GetDirectories(location); }
                catch {return;  }
            }
           
          

            foreach (string GD in LD)
            {
                // شاخه ی قبلی که در ان بودیم
                string foreTributary = "";
                // شاخه ای که در ان هستیم
                string NowTributary = GD;

                for (; ; )
                {
                    //مکان یک مقدار در یک ارایه   
                    int ex = 0;
                    // ارایه ای از پوشه های یافته شده در یک فولدر یا شاخه
                    string[] Tributaries = { };


                    try
                    {
                        Tributaries = Directory.GetDirectories(NowTributary);
                        ex = Existent(foreTributary, Tributaries);
                    }
                    catch { ex = -2; }

                    // اگر قبلا در هیچکدام از فولدرهای یافت شده نبوده نبودیم وارد اولین شاخه میشویم
                    if (ex == -1)
                    {
                        try
                        {

                            string s = NowTributary;
                            NowTributary = Tributaries[0];
                            foreTributary = s;
                        }
                        catch { ex = -2; }
                    }

                    // اگر باهر گونه مشکلی در باز کردن فولدر ها برخورد کردیم یا فولدری که در ان بودیم اخرین فولدر ان شاخه بود یک شاخه به عقب بر میگردیم
                lable:
                    if (ex == -2)
                    {
                        //  اگر فولدری که در ان هستیم همان فولدری باشد که دستور داده شده بود ان را بگردیم از حلقه خارج میشود 
                        /*  با توجه به ماهیت این  شی که شاخه ها از درونی ترین(آخر به اول) فولدر
                         * های خود ذخیره میشوند پس فولدری که شاخه اصلی است اخرین فولدری است که که پیدا میشود
                         */
                        Added(NowTributary, new EventArgs());

                        if (NowTributary == GD)
                            break;
                        foreTributary = NowTributary;
                        NowTributary = BackOfTributary(NowTributary);
                    }

                    // اگر قبلا در یک از فولدر ها بوده باشیم به فولدر بعدی در ان شاخه حرکت میکنیم
                    if (ex != -1 && ex != -2)
                    {
                        if (ex == Tributaries.Length - 1)
                        {
                            ex = -2;
                            goto lable;
                        }

                        string s = NowTributary;
                        NowTributary = Tributaries[ex + 1];
                        foreTributary = s;
                    }


                }

            }
            Disposing(System.Threading.Thread.CurrentThread.Name, new EventArgs());
        }

        // مکان یک مقدار را در ارایه پیدا میکند اگر پیدا نشد -1 برمیگرداند
        private int Existent(string Value, string[] huntThis)
        {
            int Number = 0;
            foreach (string s in huntThis)
            {
                if (Value == s)
                    return Number;
                Number++;
            }
            return -1;
        }
        // یک شاخه به عقب برمیگردد 
        private string BackOfTributary(string Tributary)
        {
            int A = 0;
            int B = 0;
            for (int i = Tributary.Length - 1; i > 0; i--)
            {
                if (Tributary[i] == '\\')
                {
                    if (B == 1)
                    {
                        Tributary = Tributary.Substring(0, A);
                        return Tributary;
                    }
                    if (B == 0)
                    {
                        B++;
                        A = i;
                    }
                }
            }
            if (B == 1)
            {
                Tributary = Tributary.Substring(0, ++A);
                return Tributary;
            }

            return Tributary;
        }
    }
}
