﻿
using System.Collections.Generic;
using System.IO;

namespace database_myVideos_Locations
{
    class Find
    {
        //  سازنده : امیرحسین بیدار کهنمویی
        // 6/12/1395 شمسی
        public List<string> AllFolders(string location)
        {
            List<string> Data = new List<string>();

            string[] LD = Directory.GetDirectories(location);

            foreach (string GD in LD)
            {
                // شاخه ی قبلی که در ان بودیم
                string foreTributary = "";
                // شاخه ای که در ان هستیم
                string NowTributary = GD;

                for (; ; )
                {
                    //مکان یک مقدار در یک ارایه   
                    int ex = 0;
                    // ارایه ای از پوشه های یافته شده در یک فولدر یا شاخه
                    string[] Tributaries = { };


                    try
                    {
                        Tributaries = Directory.GetDirectories(NowTributary);
                        ex = Existent(foreTributary, Tributaries);
                    }
                    catch { ex = -2; }

                    // اگر قبلا در هیچکدام از فولدرهای یافت شده نبوده نبودیم وارد اولین شاخه میشویم
                    if (ex == -1)
                    {
                        try
                        {

                            string s = NowTributary;
                            NowTributary = Tributaries[0];
                            foreTributary = s;
                        }
                        catch { ex = -2; }
                    }

                    // اگر باهر گونه مشکلی در باز کردن فولدر ها برخورد کردیم یا فولدری که در ان بودیم اخرین فولدر ان شاخه بود یک شاخه به عقب بر میگردیم
                lable:
                    if (ex == -2)
                    {
                        Data.Add(NowTributary);
                        //  اگر فولدری که در ان هستیم همان فولدری باشد که دستور داده شده بود ان را بگردیم از حلقه خارج میشود 
                        /*  با توجه به ماهیت این  شی که شاخه ها از درونی ترین(آخر به اول) فولدر های خود ذخیره میشوند پس فولدری که شاخه اصلی است اخرین فولدری است که که پیدا میشود
                         */
                        if (NowTributary == GD)
                            break;
                        foreTributary = NowTributary;
                        NowTributary = BackOfTributary(NowTributary);
                    }

                    // اگر قبلا در یک از فولدر ها بوده باشیم به فولدر بعدی در ان شاخه حرکت میکنیم
                    if (ex != -1 && ex != -2)
                    {
                        if (ex == Tributaries.Length - 1)
                        {
                            ex = -2;
                            goto lable;
                        }

                        string s = NowTributary;
                        NowTributary = Tributaries[ex + 1];
                        foreTributary = s;
                    }


                }

            }

            return Data;
        }

        // مکان یک مقدار را در ارایه پیدا میکند اگر پیدا نشد -1 برمیگرداند
        private int Existent(string Value, string[] huntThis)
        {
            int Number = 0;
            foreach (string s in huntThis)
            {
                if (Value == s)
                    return Number;
                Number++;
            }
            return -1;
        }
        // یک شاخه به عقب برمیگردد 
        private string BackOfTributary(string Tributary)
        {
            int A = 0;
            int B = 0;
            for (int i = Tributary.Length - 1; i > 0; i--)
            {
                if (Tributary[i] == '\\')
                {
                    if (B == 1)
                    {
                        Tributary = Tributary.Substring(0, A);
                        return Tributary;
                    }
                    if (B == 0)
                    {
                        B++;
                        A = i;
                    }
                }
            }
            if (B == 1)
            {
                Tributary = Tributary.Substring(0, ++A);
                return Tributary;
            }

            return Tributary;
        }
    }
}
