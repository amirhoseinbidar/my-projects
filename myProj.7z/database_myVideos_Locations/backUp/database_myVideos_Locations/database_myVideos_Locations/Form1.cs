﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace database_myVideos_Locations
{
    public partial class Form1 : Form
    {
        Find F = new Find();
        public Form1()
        {
          InitializeComponent();        
          ArrayToString( F.AllFolders(@"I:\serial"));
          Directory.GetFiles("D:\\");
        }

        private void ArrayToString(List<string> s)
        {

            for (int i = 0; i < s.Count ; i++ )
            {
                richTextBox2.Text += s[i] + "\r\n";
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
